# app.py

from flask import Flask, jsonify, render_template, request, redirect, session, url_for, flash
import pyrebase
import razorpay
import json
from config import FIREBASE_CONFIG, RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET

app = Flask(__name__)
app.secret_key = 'canteen123'  # Replace with a secure secret key

# Initialize Firebase
firebase = pyrebase.initialize_app(FIREBASE_CONFIG)
auth = firebase.auth()
db = firebase.database()

# Initialize Razorpay client
razorpay_client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))


# ---------------------------
# Home & Auth Routes

@app.route('/')
def home():
    # Redirect to login if the user is not logged in
    if session.get('user'):
        # If logged in, redirect based on role
        if session.get('role') == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('menu'))
    return redirect(url_for('login'))


@app.route('/update_order_status', methods=['POST'])
def update_order_status():
    if session.get('role') != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    data = request.get_json()
    order_id = data.get('order_id')
    new_status = data.get('new_status')

    if not order_id or not new_status:
        return jsonify({'success': False, 'error': 'Missing order_id or new_status'}), 400

    try:
        # Update the order status in Firebase
        db.child("orders").child(order_id).update({"status": new_status})
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/delete_item/<item_id>', methods=['POST'])
def delete_item(item_id):
    # Only allow deletion if the user is an admin
    if session.get('role') != 'admin':
        flash("Access denied.", "danger")
        return redirect(url_for('menu'))
    try:
        # Remove the item from the "menu" node in Firebase
        db.child("menu").child(item_id).remove()
        flash("Item deleted successfully.", "success")
    except Exception as e:
        flash(f"Error deleting item: {e}", "danger")
    return redirect(url_for('menu'))


# ---------------------------
# User Registration & Login
# ---------------------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        roll_no = request.form['roll_no']
        phone = request.form['phone']

        try:
            # Create user in Firebase Authentication
            user = auth.create_user_with_email_and_password(email, password)
            uid = user['localId']

            # Save additional user info in database
            data = {
                "name": name,
                "email": email,
                "roll_no": roll_no,
                "phone": phone,
                "role": "admin" if email == "admincanteen@gmail.com" else "student"
            }
            db.child("users").child(uid).set(data)
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for('login'))
        except Exception as e:
            try:
                # Attempt to parse the error details from Pyrebase
                error_json = e.args[1]
                # If error_json is a string, parse it to a dict
                if isinstance(error_json, str):
                    error_json = json.loads(error_json)
                error_message = error_json['error']['message']
            except Exception:
                error_message = str(e)
                
            if error_message == "EMAIL_EXISTS":
                flash("This email is already registered. Please log in.", "danger")
            else:
                flash(f"Registration failed: {error_message}", "danger")
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        try:
            user = auth.sign_in_with_email_and_password(email, password)
            session['user'] = user
            # Check if the user is admin based on email
            if email == "admincanteen@gmail.com":
                session['role'] = 'admin'
                return redirect(url_for('admin_dashboard'))
            else:
                session['role'] = 'student'
                return redirect(url_for('menu'))
        except Exception as e:
            flash(f"Login failed: {e}", "danger")
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# ---------------------------
# Menu & Order Routes
# ---------------------------
@app.route('/menu')
def menu():
    # Fetch menu items from Firebase (assumed stored under 'menu')
    items = db.child("menu").get().val()
    return render_template('menu.html', items=items)


@app.route('/order', methods=['POST'])
def order():
    if request.method == 'POST':
        # Get the selected item and quantity from the form
        item_id = request.form['item_id']
        quantity = int(request.form['quantity'])

        # Fetch the item details from Firebase
        item = db.child("menu").child(item_id).get().val()
        if not item:
            flash("Item not found.", "danger")
            return redirect(url_for('menu'))

        # Calculate total amount (in paise)
        total_amount = int(item['price'] * quantity * 100)

        # Create a Razorpay order
        try:
            razorpay_order = razorpay_client.order.create({
                'amount': total_amount,
                'currency': 'INR',
                'payment_capture': '1'
            })
        except Exception as e:
            flash(f"Error creating payment order: {e}", "danger")
            return redirect(url_for('menu'))

        # Fetch the student's details from Firebase
        student = db.child("users").child(session['user']['localId']).get().val()

        # Create the order data including student details
        order_data = {
            "user": session['user']['localId'],
            "student_name": student.get("name"),
            "student_phone": student.get("phone"),
            "student_roll_no": student.get("roll_no"),
            "item": item,  # item contains details like name, description, price, image_url
            "quantity": quantity,
            "razorpay_order_id": razorpay_order['id'],
            "status": "pending"
        }
        # Save the order details to Firebase
        db.child("orders").push(order_data)

        return render_template('payment.html', 
                               razorpay_order=razorpay_order,
                               key_id=RAZORPAY_KEY_ID,
                               total_amount=total_amount,
                               item=item)
    return redirect(url_for('menu'))

# ---------------------------
# Admin Routes
# ---------------------------
@app.route('/admin/dashboard')
def admin_dashboard():
    # Protect route: only allow admin access
    if session.get('role') != 'admin':
        flash("Access denied.", "danger")
        return redirect(url_for('login'))
    # Fetch orders or any admin specific data
    orders = db.child("orders").get().val()
    return render_template('admin_dashboard.html', orders=orders)


@app.route('/admin/upload', methods=['GET', 'POST'])
def admin_upload():
    if session.get('role') != 'admin':
        flash("Access denied.", "danger")
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = float(request.form['price'])
        image_url = request.form['image_url']
        category = request.form['category']


        data = {
            "name": name,
            "description": description,
            "price": price,
            "image_url": image_url,
            "category": category
        }
        # Push new menu item to Firebase under 'menu'
        db.child("menu").push(data)
        flash("Item added successfully!", "success")
        return redirect(url_for('menu'))
    return render_template('admin_upload.html')

# ---------------------------
# Payment Verification
# ---------------------------
@app.route('/payment/success', methods=['POST'])
def payment_success():
    # Razorpay sends payment details via POST after payment
    payment_data = request.form.to_dict()

    # (OPTIONAL) Verify payment signature here using:
    # razorpay_client.utility.verify_payment_signature(payment_data)

    order_id = payment_data.get('razorpay_order_id')

    # Update order status in Firebase (this is a simplified example)
    orders = db.child("orders").get().val()
    if orders:
        for key, order in orders.items():
            if order.get("razorpay_order_id") == order_id:
                db.child("orders").child(key).update({"status": "paid"})
                break
    flash("Payment successful!", "success")
    return redirect(url_for('menu'))

if __name__ == '__main__':
    app.run(debug=True)
