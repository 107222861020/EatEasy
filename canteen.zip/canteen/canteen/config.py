# config.py

FIREBASE_CONFIG = {
    "apiKey": "AIzaSyCH6Kx3speUvl8vvWJlIBXu9DwDurDcBnM",
    "authDomain": "explore-b1a73.firebaseapp.com",
    "databaseURL": "https://explore-b1a73-default-rtdb.firebaseio.com/",  # Update with your actual database URL
    "projectId": "explore-b1a73",
    "storageBucket": "explore-b1a73.firebasestorage.app",
    "messagingSenderId": "64533833522",
    "appId": "1:64533833522:web:620097364c3e9d639d192b"
}

# Razorpay configuration 
RAZORPAY_KEY_ID = "rzp_test_l6RvqOlpSdY8jH"
RAZORPAY_KEY_SECRET = "RnF0iEYOHjsEbQXNac3A7Cg9"
